"""
Relax Inc. Data Science Challenge — User Adoption Analysis
"""
import pandas as pd
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import roc_auc_score, classification_report
from sklearn.preprocessing import StandardScaler

plt.rcParams.update({"figure.dpi": 150, "font.size": 9})

DATA = "/tmp/relax_challenge/relax_challenge"
OUT = "/mnt/user-data/outputs"
import os
os.makedirs(OUT, exist_ok=True)

# ---------------------------------------------------------------
# 1. Load data
# ---------------------------------------------------------------
users = pd.read_csv(f"{DATA}/takehome_users.csv", encoding="latin-1",
                     parse_dates=["creation_time"])
engagement = pd.read_csv(f"{DATA}/takehome_user_engagement.csv",
                          parse_dates=["time_stamp"])

print("users shape:", users.shape)
print("engagement shape:", engagement.shape)
print(users.dtypes)
print(users.isna().sum())

# ---------------------------------------------------------------
# 2. Define "adopted user": logged in on 3 separate days within any
#    rolling 7-day window.
# ---------------------------------------------------------------
engagement = engagement.sort_values(["user_id", "time_stamp"])
# Keep only distinct login days per user (a user could in theory have
# multiple rows same day, though this dataset is one row per login event).
engagement["date"] = engagement["time_stamp"].dt.normalize()
logins = engagement.drop_duplicates(["user_id", "date"])[["user_id", "date"]]

def is_adopted(dates):
    dates = dates.sort_values().to_numpy()
    if len(dates) < 3:
        return False
    # sliding window: for each login, check if 2 more logins occur within
    # 6 days after it (i.e., 3 logins spanning <=7 days)
    dates = dates.astype("datetime64[D]")
    for i in range(len(dates) - 2):
        if (dates[i + 2] - dates[i]).astype(int) <= 6:
            return True
    return False

adopted_flags = logins.groupby("user_id")["date"].apply(is_adopted)
adopted_flags.name = "adopted"
adopted_flags = adopted_flags.reset_index().rename(columns={"user_id": "object_id"})

print("Total users with >=1 login:", logins["user_id"].nunique())
print("Adopted users:", adopted_flags["adopted"].sum())
print("Adoption rate among logged-in users: {:.1%}".format(adopted_flags["adopted"].mean()))

# ---------------------------------------------------------------
# 3. Merge with user table; users with no engagement rows -> not adopted
# ---------------------------------------------------------------
df = users.merge(adopted_flags, on="object_id", how="left")
df["adopted"] = df["adopted"].fillna(False)
print("Overall adoption rate (all 12k users): {:.1%}".format(df["adopted"].mean()))

# ---------------------------------------------------------------
# 4. Feature engineering
# ---------------------------------------------------------------
df["opted_in_to_mailing_list"] = df["opted_in_to_mailing_list"].astype(int)
df["enabled_for_marketing_drip"] = df["enabled_for_marketing_drip"].astype(int)
df["was_invited"] = df["invited_by_user_id"].notna().astype(int)

# org size (number of users in org) as proxy for team-driven usage
org_size = df.groupby("org_id")["object_id"].transform("count")
df["org_size"] = org_size

# account age in days relative to most recent creation_time in dataset
max_date = df["creation_time"].max()
df["account_age_days"] = (max_date - df["creation_time"]).dt.days

# creation_time seasonality features
df["creation_year"] = df["creation_time"].dt.year
df["creation_dow"] = df["creation_time"].dt.dayofweek

# one-hot encode creation_source
source_dummies = pd.get_dummies(df["creation_source"], prefix="src")
df = pd.concat([df, source_dummies], axis=1)

feature_cols = (
    ["opted_in_to_mailing_list", "enabled_for_marketing_drip", "was_invited",
     "org_size", "account_age_days"]
    + list(source_dummies.columns)
)

X = df[feature_cols].copy()
y = df["adopted"].astype(int)

print("\nFeature matrix shape:", X.shape)
print(X.isna().sum())

# ---------------------------------------------------------------
# 5. Descriptive cross-tabs (for writeup)
# ---------------------------------------------------------------
by_source = df.groupby("creation_source")["adopted"].agg(["mean", "count"])
print("\nAdoption rate by creation_source:\n", by_source)

by_invited = df.groupby("was_invited")["adopted"].agg(["mean", "count"])
print("\nAdoption rate by was_invited:\n", by_invited)

by_mailing = df.groupby("opted_in_to_mailing_list")["adopted"].agg(["mean", "count"])
print("\nAdoption rate by opted_in_to_mailing_list:\n", by_mailing)

by_drip = df.groupby("enabled_for_marketing_drip")["adopted"].agg(["mean", "count"])
print("\nAdoption rate by enabled_for_marketing_drip:\n", by_drip)

df["org_size_bucket"] = pd.cut(df["org_size"], bins=[0, 1, 5, 20, 100, 10000],
                                labels=["1", "2-5", "6-20", "21-100", "100+"])
by_orgsize = df.groupby("org_size_bucket", observed=True)["adopted"].agg(["mean", "count"])
print("\nAdoption rate by org_size_bucket:\n", by_orgsize)

# ---------------------------------------------------------------
# 6. Modeling
# ---------------------------------------------------------------
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.25, random_state=42, stratify=y
)

scaler = StandardScaler()
X_train_s = scaler.fit_transform(X_train)
X_test_s = scaler.transform(X_test)

logreg = LogisticRegression(max_iter=1000, class_weight="balanced")
logreg.fit(X_train_s, y_train)
logreg_auc = roc_auc_score(y_test, logreg.predict_proba(X_test_s)[:, 1])
print("\nLogistic Regression AUC:", round(logreg_auc, 3))

coef_table = pd.Series(logreg.coef_[0], index=feature_cols).sort_values()
print("\nLogistic regression coefficients (standardized):\n", coef_table)

rf = RandomForestClassifier(n_estimators=300, max_depth=6, min_samples_leaf=20,
                             class_weight="balanced", random_state=42, n_jobs=-1)
rf.fit(X_train, y_train)
rf_auc = roc_auc_score(y_test, rf.predict_proba(X_test)[:, 1])
print("\nRandom Forest AUC:", round(rf_auc, 3))

importances = pd.Series(rf.feature_importances_, index=feature_cols).sort_values(ascending=False)
print("\nRandom Forest feature importances:\n", importances)

# ---------------------------------------------------------------
# 7. Charts
# ---------------------------------------------------------------
fig, axes = plt.subplots(1, 2, figsize=(9, 3.5))

importances.sort_values().plot(kind="barh", ax=axes[0], color="#3b7ddd")
axes[0].set_title("Random Forest feature importance")
axes[0].set_xlabel("Importance")

by_orgsize["mean"].plot(kind="bar", ax=axes[1], color="#3b7ddd")
axes[1].set_title("Adoption rate by org size")
axes[1].set_ylabel("Adoption rate")
axes[1].tick_params(axis="x", rotation=0)

plt.tight_layout()
plt.savefig(f"{OUT}/adoption_analysis_charts.png", bbox_inches="tight")
print(f"\nSaved chart to {OUT}/adoption_analysis_charts.png")

# Save summary tables to CSV for reference
summary = pd.concat({
    "by_source": by_source,
    "by_invited": by_invited,
    "by_mailing_optin": by_mailing,
    "by_marketing_drip": by_drip,
}, names=["segment", "value"])
summary.to_csv(f"{OUT}/adoption_summary_tables.csv")

importances.to_csv(f"{OUT}/rf_feature_importances.csv", header=["importance"])
coef_table.to_csv(f"{OUT}/logreg_coefficients.csv", header=["coefficient"])

print("\nDONE")
